#include <avr/io.h>
#include <avr/pgmspace.h>
#include "main.h"

// These are the times based on the NEC protocol.
const uint16_t code_NEC_BENQ_PROJECTOR_Times[] PROGMEM = {  
  56, 160,
  56, 56,
  900, 450,
  56, 0
};

/*10000100   0x84
00010101   0x15
00010001   0x11
01000000   0x40
01010101   0x55
01010101   0x55
01000000   0x40
00000000   0x00
0011_0000  0x30*/

const struct IrCode code_NEC_BENQ_PROJECTOR_Code PROGMEM = {
  freq_to_timerval(38462), //38404
  34,
  2,
  code_NEC_BENQ_PROJECTOR_Times,
  {
    0x84,
    0x15,
    0x11,
    0x40,
    0x55,
    0x55,
    0x40,
    0x00,
    0x30
  }
};

// These are the times I observed with my receiver.
const uint16_t code_NEC_BENQ_PROJECTOR_Times2[] PROGMEM = {  
  49, 170,
  49, 66,
  900, 460,
  50, 0
};

const struct IrCode code_NEC_BENQ_PROJECTOR_Code2 PROGMEM = {
  freq_to_timerval(38462), //38404
  34,
  2,
  code_NEC_BENQ_PROJECTOR_Times2,
  {
    0x84,
    0x15,
    0x11,
    0x40,
    0x55,
    0x55,
    0x40,
    0x00,
    0x30
  }
};


const uint16_t code_RCA_SAMSUNG_LCD_Times[] PROGMEM = {  
  55, 165,
  55, 55,
  450, 450,
  60, 0
};

const struct IrCode code_RCA_SAMSUNG_LCD_Code PROGMEM = {
  freq_to_timerval(38462),
  34,
  2,
  code_RCA_SAMSUNG_LCD_Times,
  {
    0x80,
    0x55,
    0x40,
    0x55,
    0x51,
    0x55,
    0x44,
    0x00,
    0x30
  }
};

////////////////////////////////////////////////////////////////


const struct IrCode *NApowerCodes[] PROGMEM = {
	&code_NEC_BENQ_PROJECTOR_Code//,
  //&code_NEC_BENQ_PROJECTOR_Code2,
  //&code_RCA_SAMSUNG_LCD_Code
}; 

const uint8_t num_NAcodes = NUM_ELEM(NApowerCodes);

