#include "Wire.h"
#include "rtc.h"
#include "defs.h"

//====================================
// Convert normal decimal numbers to binary coded decimal
byte dec_to_bcd(byte val)
{
  return ( (val/10*16) + (val%10) );
}

//====================================
// Convert binary coded decimal to normal decimal numbers
byte bcd_to_dec(byte val)
{
  return ( (val/16*10) + (val%16) );
}

//====================================
void set_datetime(byte year, byte month, byte day_of_month, byte day_of_week, byte hour, byte minute, byte second) {
  Wire.beginTransmission(DS1307_I2C_ADDRESS);
  Wire.send(0);
  
  Wire.send(dec_to_bcd(second));
  Wire.send(dec_to_bcd(minute));
  Wire.send(dec_to_bcd(hour));      
  Wire.send(dec_to_bcd(day_of_week));
  Wire.send(dec_to_bcd(day_of_month));
  Wire.send(dec_to_bcd(month));
  Wire.send(dec_to_bcd(year));
  
  Wire.endTransmission();
}

//====================================
void get_datetime(byte *year, byte *month, byte *day_of_month, byte *day_of_week, byte *hour, byte *minute, byte *second) {
  Wire.beginTransmission(DS1307_I2C_ADDRESS);
  Wire.send(0);
  Wire.endTransmission();

  Wire.requestFrom(DS1307_I2C_ADDRESS, 7);

  // A few of these need masks because certain bits are control bits
  *second = bcd_to_dec(Wire.receive() & 0x7f);
  *minute = bcd_to_dec(Wire.receive());
  *hour = bcd_to_dec(Wire.receive() & 0x3f);  // hour, change for 12 hour am/pm
  *day_of_week = bcd_to_dec(Wire.receive());
  *day_of_month = bcd_to_dec(Wire.receive());
  *month = bcd_to_dec(Wire.receive());
  *year = bcd_to_dec(Wire.receive());
}
