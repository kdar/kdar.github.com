#include "WProgram.h"
#include "temperature.h"
#include "defs.h"

float temperature_convert = TEMPERATURE_CONVERT;

//====================================
float get_temperature()
{
  return ((analogRead(TEMPERATURE_PIN)*temperature_convert)*1.8) + 32;
}