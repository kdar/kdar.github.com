#ifndef __TEMPERATURE_H
#define __TEMPERATURE_H

float get_temperature();

#endif
