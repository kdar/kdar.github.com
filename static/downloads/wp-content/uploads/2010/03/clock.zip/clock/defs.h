#define TEMPERATURE_PIN 0
// 466 = 2.27539V = 17.77777777777778C
// Conversion discovered by a reference temperature sensor.
// Converts A/D reading to Celsius.
#define TEMPERATURE_CONVERT (39.0653/1024.0)

#define DS1307_I2C_ADDRESS 0x68