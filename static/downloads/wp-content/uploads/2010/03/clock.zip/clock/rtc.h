#ifndef __RTC_H
#define __RTC_H

#include "WProgram.h"

byte dec_to_bcd(byte val);
byte bcd_to_dec(byte val);

void set_datetime(byte year, byte month, byte day_of_month, byte day_of_week, byte hour, byte minute, byte second);
void get_datetime(byte *year, byte *month, byte *day_of_month, byte *day_of_week, byte *hour, byte *minute, byte *second);

#endif
