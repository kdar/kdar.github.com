#include "pic24_all.h"
#include "lcd.h"

/************************************
Prototypes
*************************************/
int main(void);

/************************************
Main
*************************************/
int main(void)
{
  configClock();

  CONFIG_RB8_AS_DIG_OUTPUT();
  CONFIG_RB9_AS_DIG_OUTPUT();
  CONFIG_RB0_AS_DIG_OUTPUT();
  CONFIG_RB1_AS_DIG_OUTPUT();

  configDefaultUART(DEFAULT_BAUDRATE); //serial port config
  outString(HELLO_MSG);

  LCDInit();      //Init LCD

  //Defaults
  LCDCommand(SETCON);		//Send Contrast Command
  LCDData(35);      //Send Contrast Value(data)

  LCDFill(BLACK);
  LCDPutStr("Hello world!",50,13,0,WHITE,BLACK);

  while (1) {
  }

  return 0;
}
