#ifndef __LCD_H
#define __LCD_H

#include "pic24_all.h"

#define BIT12       //DEFINE THIS FOR 12 Bit MODE
//#define BIT8        //DEFINE THIS FOR 8 Bit MODE

//********************************************************************
//
//				General Function Definitions
//
//********************************************************************
void LCDFill(unsigned int color);
void SetXY(unsigned char x, unsigned char y);
void LCDCommand(unsigned char data);
void LCDData(unsigned char data);
void LCDInit(void);
void delay_ms(unsigned int ms);
void LCDSetPixel(unsigned int x, unsigned int y, unsigned int color);
void LCDSetLine(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned int color);
void LCDSetRect(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned char fill, unsigned int color);
void LCDSetCircle(int x0, int y0, int radius, int color);
void LCDPutChar(unsigned char c, int x, int y, int size, int fColor, int bColor);
void LCDPutStr(unsigned char *pString, int x, int y, int Size, int fColor, int bColor);
void LCDPutRomStr(const unsigned char *pString, int x, int y, int Size, int fColor, int bColor);
void LCDWriteBMP(const unsigned char *bmp, unsigned char x, unsigned char y);
//*******************************************************
//					GPIO Definitions
//*******************************************************
#define LCD_RES LATBbits.LATB8  //RESET
#define LCD_DIO LATBbits.LATB9  //SERIAL DATA
#define LCD_SCK LATBbits.LATB0  //CLOCK
#define LCD_CS  LATBbits.LATB1  //CHIP SELECT

#define LCD_TRIS TRISB
#define LCD_MASK 0xF0
//********************************************************************
//
//					LCD Dimension Definitions
//
//********************************************************************
#define ROW_LENGTH	132
#define COL_HEIGHT	132
#define ENDPAGE     132
#define ENDCOL      130
//********************************************************************
//
//			PHILLIPS Controller Commands
//
//********************************************************************
//LCD Commands
#define	NOP_         0x00
#define	BSTRON		0x03
#define SLEEPIN     0x10
#define	SLEEPOUT	0x11
#define	NORON		0x13
#define	INVOFF		0x20
#define INVON      	0x21
#define	SETCON		0x25
#define DISPOFF     0x28
#define DISPON      0x29
#define CASET       0x2A
#define PASET       0x2B
#define RAMWR       0x2C
#define RGBSET	    0x2D
#define	MADCTL		0x36
#define	COLMOD		0x3A
#define DISCTR      0xB9
#define DISCTRO     0xB8
#define	EC			0xC0
#define	TCDF		0xC6
#define SFDON       0xEF
#define SFDOFF      0xEE

#ifdef BIT12
//*******************************************************
//				12-Bit Color Definitions
//*******************************************************
#define WHITE	0xFFF
#define BLACK	0x000
#define RED		0xF00
#define	GREEN	0x0F0
#define BLUE	0x00F
#define CYAN	0x0FF
#define MAGENTA	0xF0F
#define YELLOW	0xFF0
#define BROWN	0x841
#define ORANGE	0xF70
#define PINK	0xF19
#define WideBG  000

#endif
#ifdef BIT8
//*******************************************************
//				8-Bit Color Definitions
//*******************************************************
#define WHITE	0xFF    //White
#define BLACK	0x00    //Black
#define RED		0xE0    //Red
#define	GREEN	0x1C    //Green
#define BLUE	0x03    //Blue
#define CYAN	0x1F    //Cyan
#define MAGENTA	0xE3    //Magenta
#define YELLOW	0xFC    //Yellow
#define BROWN	0x88    //Brown
#define ORANGE	0xEC    //Dark Orange
#define PINK	0xE2    //Pink
#define WideBG  0x0F
#endif


#endif
